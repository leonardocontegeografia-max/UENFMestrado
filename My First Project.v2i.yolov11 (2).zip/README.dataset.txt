# My First Project > 2026-07-02 2:50pm
https://universe.roboflow.com/leonardo-conte/my-first-project-2mi6p

Provided by a Roboflow user
License: CC BY 4.0

