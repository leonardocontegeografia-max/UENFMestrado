# My First Project > barbeiro e assai
https://universe.roboflow.com/leonardo-conte/my-first-project-2mi6p

Provided by a Roboflow user
License: CC BY 4.0

